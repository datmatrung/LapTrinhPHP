<?php
require_once("connect.php");
$db = new Database();
$statement = "delete from product where id=?";
$param = ["{$_GET['id']}"];
$stmt = $db->updateParam($statement,$param);
header("location: index.php");
