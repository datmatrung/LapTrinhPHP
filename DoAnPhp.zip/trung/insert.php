<?php
require_once("connect.php");
$db = new Database();
if($_SERVER['REQUEST_METHOD']==='POST'):
    if($_FILES['photo']['name'] != ''):
        move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'. $_FILES['photo']['name']);
        $photo = $_FILES['photo']['name'];
    else:
        $photo = $_POST['oldphoto'];
    endif;
    $statement = "insert into product(name_pro, price, quantity, description_pro, photo, status_pro, create_date) values (?,?,?,?,?,?,?)";
    $param = [
        $_POST['name_pro'],
        $_POST['price'],
        $_POST['quantity'],
        $_POST['description'],
        $photo,
        $_POST['status'],
        $_POST['date'],
    ];
    $db->updateParam($statement, $param);

    header("location: index.php");

endif;

?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insert Product</title>
</head>
<body>
<form action="#" method="post" enctype="multipart/form-data">

    <label for="name_pro">name</label><br/>
    <input type="text" name="name_pro"><br/>

    <label for="price">price</label><br/>
    <input type="number" name="price"><br/>

    <label for="quantity">quantity</label><br/>
    <input type="number" name="quantity"><br/>

    <label for="description">description</label><br/>
    <textarea cols="30" rows="10" name="description"></textarea><br/>

    <label for="photo">photo</label><br/>
    <input type="file" name="photo"><br/>

    <label for="status">status</label><br/>
    <input type="checkbox" name="status" checked /><br/>

    <label for="date">date</label><br/>
    <input type="date" name="date" /> <br/> <hr/>

    <input type="submit" value="update">

</form>
</body>
</html>