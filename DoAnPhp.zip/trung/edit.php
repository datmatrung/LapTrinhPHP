<?php
require_once("connect.php");
$db = new Database();
if($_SERVER['REQUEST_METHOD']==='POST'):
    if($_FILES['photo']['name'] != ''):
        // unlink('images/' . $_POST['oldphoto']);
        move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'. $_FILES['photo']['name']);
        $photo = $_FILES['photo']['name'];
    else:
        $photo = $_POST['oldphoto'];
    endif;

    $statement = "update product set name_pro=?, price=?, quantity=?, description_pro=?, photo=?, status_pro=?, create_date=? where id=?";
    $param = [
        $_POST['name_pro'],
        $_POST['price'],
        $_POST['quantity'],
        $_POST['description'],
        $photo,
        $_POST['status'],
        $_POST['date'],
        $_GET['id'],
    ];

    $db->updateParam($statement, $param);

    header("location: index.php");

else:
    $statement = "select * from product where id=?";
    $param = ["{$_GET['id']}"];
    $stmt = $db->selectDataParam($statement,$param);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    extract($product);
endif;

?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
</head>
<body>
<form action="#" method="post" enctype="multipart/form-data">

    <label for="name_pro">name</label><br/>
    <input type="text" name="name_pro" value="<?= $name_pro?>"><br/>

    <label for="price">price</label><br/>
    <input type="number" name="price" value="<?= $price?>"><br/>

    <label for="quantity">quantity</label><br/>
    <input type="number" name="quantity" value="<?= $quantity?>"><br/>

    <label for="description">description</label><br/>
    <textarea cols="30" rows="10" name="description"> <?= $description_pro?> </textarea><br/>

    <label for="photo">photo</label><br/>
    <img src="images/<?=$photo?>" width="100" height="100"><br/>
    <input type="hidden" name="oldphoto" value="<?=$photo?>">
    <input type="file" name="photo"><br/>

    <label for="status">status</label><br/>
    <input type="checkbox" name="status" <?= $status_pro? "checked":""; ?><br/>

    <label for="date">date</label><br/>
    <input type="date" name="date" value="<?= $create_date?>"> <br/> <hr/>

    <input type="submit" value="update">

</form>
</body>
</html>